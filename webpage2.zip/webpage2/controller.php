<?php 
		function db(){
		return new PDO("mysql:host=localhost;dbname=MTC","root","");
		}


	function register($fname, $lname, $email, $password){
		$db = db();
		$sql = "INSERT INTO `user` (`first_name`, `last_name`, `email`, `password`, `status`) VALUES (?,?,?,?,?);";
		$cmd = $db->prepare($sql);
		$result = $cmd->execute(array($fname, $lname, $email, $password, 1));
		$db = null;		
		return "ok";

	}
	function login($email, $password){
		$db = db();
		$sql = "SELECT * FROM `user` WHERE `email` = "$email" AND `password` ="$password";";
		$cmd = $db->prepare($sql);
		$result = $cmd->execute(array($email, $password));
		$resultfetch = $result->fetchAll();
		$db = null;		
		if ($resultfetch > 0){
			return "ok";

		}else{
			return "no user found";
		}


	}

	
 ?>