<?php
    require ("controller.php");
    $email;
    $password;

    if(isset($_POST['botn']))
    {
            
            $email = $_POST['email'];
            $password = $_POST['passwrd'];
        

        echo login($email,$password); 
         
    }



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>loginpage</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Quicksand">
    <link rel="stylesheet" href="assets/css/Login-with-overlay-image.css">
    <link rel="stylesheet" href="assets/css/OcOrato---Login-form-styles.css">
    <link rel="stylesheet" href="assets/css/OcOrato---Login-form.css">
</head>

<body>
    <form id="form" style="font-family: Quicksand, sans-serif;background-color: rgba(255,255,255,0.73);width: 320px;padding: 40px;">
        <h1 id="head" style="color:rgb(193,166,83);">Login page&nbsp;</h1>
        <div class="d-md-flex d-xl-flex justify-content-md-center align-items-xl-center"><img class="rounded img-fluid" id="image" style="width:auto;height:auto;" src="assets/img/logo_75df62bfb3d75ba6978524d3f4e71428_2x.png"></div>
        <div class="form-group mb-3"><input class="form-control" name= "email" type="email" id="formum" placeholder="Email"></div>
        <div class="form-group mb-3"><input class="form-control" name= "passwrd" type="password" id="formum2" placeholder="Password"></div><button class="btn btn-light" id="butonas" style="width:100%;height:100%;margin-bottom:10px;background-color:rgb(106,176,209);" name= "botn" type="button">Login</button><a id="linkas" style="font-size:12px;margin:auto;margin-left:0;margin-right:0;margin-bottom:0;margin-top:0;padding-left:0;padding-right:0;color:rgb(177,151,70);" href="#">Forgot your e mail or password?</a>
    </form>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>