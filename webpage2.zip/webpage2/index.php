<?php
    require("controller.php");
    $fname;
    $lname;
    $email;
    $password;
    
    if(isset($_POST['Reg']))
    {
            $fname = $_POST['FirstName'];
            $lname = $_POST['LastName'];
            $email = $_POST['email'];
            $password = $_POST['pwpassword-repeat'];
        

        echo Register($fname, $lname,$email,$password);  
    }
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Registerpage</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Ludens-Users---2-Register.css">
</head>

<body>
    <section class="register-photo" style="background-color: transparent;background-image: url(&quot;assets/img/read-more.jpeg&quot;);">
        <div class="form-container" style="margin-top: 40px;">
            <div class="image-holder" style="background: url(&quot;assets/img/open-book-1428428__340.jpeg&quot;) left / cover no-repeat;"></div>
            <form method="post" style="height: 525px;background-color: rgba(255,255,255,0.73);">
                <h2 class="text-center"><strong>Register Page</strong></h2>
                <div class="form-group mb-3">
                    <div class="d-xl-flex"><input class="form-control d-xl-flex justify-content-xl-center align-items-xl-center" type="text" style="margin-bottom: 14px;" placeholder="First Name" name="FirstName"><input class="form-control" type="text" style="margin-left: 15px;" name="LastName" placeholder="Last Name"></div><input class="form-control" type="email" name="email" placeholder="email adress">
                </div>
                <div class="form-group mb-3"><input class="form-control" type="password" id="password" name="password" placeholder="password" onchange="changePassword()"></div>
                <div class="form-group mb-3"><input class="form-control" type="password" id="confirmPassword" name="password-repeat" placeholder="Repeat password" onchange="changePassword()"></div>
                <div id="passwordsError" style="display: none;margin-bottom: 16.5px;"><span id="errorMessage" class="text-danger" style="font-size:13px;"></span></div>
                <div class="form-group mb-3">
                    <div class="form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox">By checking this box you agree to sell your soul to us</label></div>
                </div>
                <div class="form-group mb-3">
                    <button class="btn btn-primary d-block w-100" id="submitButton" name="Reg"  type="submit" style="color: rgb(255,255,255);background-color: #00b5a8;">Register</button>
                </div>
            <a class="already" href="login.html">already have an account? login <span style="text-decoration: underline;">here</span></a>
            </form>
        </div>
    </section>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script>
    // Submit button made with javascript
    function changePassword() {
        var password = document.querySelector("#password").value;
        var confirmPassword = document.querySelector("#confirmPassword").value;
        
        if(password.length >= 8) {
            if(password === confirmPassword)
            {
                var btn = $('#submitButton').removeAttr("disabled");
                document.querySelector('#passwordsError').style.display = 'none';
                console.log("enabling")
            }
            else {
                var btn = $('#submitButton').attr("disabled", "true");
                document.querySelector('#passwordsError').style.display = 'block';
                document.querySelector('#errorMessage').innerHTML = 'The passwords do not match';
                console.log("disabling")
            }
        }
        else {
            var btn = $('#submitButton').attr("disabled", "true");
            document.querySelector('#passwordsError').style.display = 'block';
            document.querySelector('#errorMessage').innerHTML = 'The password must be at least 8 characters long';
            console.log("disabling")
        }
    }
</script>
</body>

</html>