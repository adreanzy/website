<?php
    require("controller.php");
    $fname;
    $lname;
    $email;
    $password;
    
    if(isset($_POST['Reg']))
    {
            $fname = $_POST['FirstName'];
            $lname = $_POST['LastName'];
            $email = $_POST['email'];
            $password = $_POST['password'];
        

        echo Register($fname, $lname,$email,$password);  
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Registerpage</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Ludens-Users---2-Register.css">
</head>

<body>
    <section class="register-photo" style="background-color: transparent;background-image: url(&quot;assets/img/read-more.jpeg&quot;);">
        <div class="form-container" style="margin-top: 40px;">
            <div class="image-holder" style="background: url(&quot;assets/img/open-book-1428428__340.jpeg&quot;) left / cover no-repeat;"></div>
            <form method="post" action = '' style="height: 525px;background-color: rgba(255,255,255,0.73);">
                <h2 class="text-center"><strong>Register Page</strong></h2>
                <div class="form-group mb-3">
                    <div class="d-xl-flex"><input class="form-control d-xl-flex justify-content-xl-center align-items-xl-center" type="text" style="margin-bottom: 14px;" placeholder="First Name" name="FirstName"><input class="form-control" type="text" style="margin-left: 15px;" name="LastName" placeholder="Last Name"></div><input class="form-control" type="email" name="email" placeholder="email adress"><input class="form-control" type="password" style="margin-top: 16px;" placeholder="password" name="password">
                </div>
                <div class="form-group mb-3 text-center"><button class="btn btn-primary d-block w-100" name= "Reg"id="submitButton" type="submit" style="color: rgb(255,255,255);background-color: #00b5a8;">Register</button>
                <a class="text-center" href="loginpage.php" style="text-align: left;">Log In</a>
            </div>
            </form>
        </div>
    </section>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>